/**
 * Curso: Programación
 *
 * Temas: Arreglos Bidimensionales aplicados
 *          para representar operaciones con matrices
 *
 * @author Roberto Méndez Méndez
 * @version 1/Oct/22
 *
 *  Actividad para el alumno:
 *    Arreglar los métodos de manera que reciban objetos del tipo
 *    Matriz2D e implementar cada uno de los métodos
 */

package matricesArray2D;

public class OpracionesConMatrices2D {

    public static double[][] sumaAB(double[][] a,
                                          double[][] b ){
        double[][] c = new double[a.length][b[0].length];
        return c;
    }

    public static double productoAB(double[][] a,
                                         double[][] b ){
        double[][] c = new double[a.length][b[0].length];
        return 0;

    }
    public static double determinanteA(double[][] a,
                                     double[][] b ){
        return 0;
    }

    public static boolean isToeplitz(){

        return true;
    }

}
