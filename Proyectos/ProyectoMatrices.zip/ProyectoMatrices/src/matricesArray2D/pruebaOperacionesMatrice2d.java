/**
 * Curso: Programación
 *
 * Temas: Arreglos Bidimensionales aplicados
 *          para representar operaciones con matrices
 *
 * @author Roberto Méndez Méndez
 * @version 1/Oct/22
 *
 *  Actividad para el alumno:
 *    Probar los métodos de OperacionesMAtrices2D y
 *    MAtrizArreglo2D
 */

package matricesArray2D;

public class pruebaOperacionesMatrice2d {
}
