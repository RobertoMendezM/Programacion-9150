/**
 *  Programa que permitirá realizar
 *  operaciones con puntos en la forma P = (x,y)
 *
 *  NOTA: DEBEN IMPLEMENTAR LOS MÉTODOS
 *
 *  Curso: Matemáticas para ciencias Aplicadas
 *
 *  Temas:  Función distancia, producto punto y
 *          su aplicación para obtener el área
 *
 *  @author Roberto Méndez Méndez
 *  @version  22-Septiembre-22
 */


package Metricas1;

public class OperacionesConPuntos2D {


    public static double normaEuclideana(Punto2D p) { return 0; }


    public static double metricaEuclidiana(Punto2D a, Punto2D b) { return 0;}


    public static double metricaTaxista(Punto2D a, Punto2D b) { return 0; }


    public static double dotProduct(Punto2D a, Punto2D b) { return 0; }


    public double areaPalalelogramo(Punto2D a, Punto2D b) { return 0; }
}
