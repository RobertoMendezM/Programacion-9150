package miPaquete;

public class LLamaUnNumero {
    private int numero;

    public LLamaUnNumero(){
        this.numero = 10;
    }

    public int getNumero(){
        return numero;
    }

}
